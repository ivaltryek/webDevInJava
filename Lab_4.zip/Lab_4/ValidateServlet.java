/*
	 Lab:4-Working with Servlets (delegating the request) and JSP
      		 1.Write a Java web application for a login module which contains the following components:
		    ->index.html
		    ->*ValidateServlet.java
		    ->WelcomeServlet.java

*/

package com.app;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.Enumeration;
import javax.servlet.RequestDispatcher;

public class CheckLogin extends HttpServlet {
    Connection conn = null;
    PreparedStatement pst = null;
    RequestDispatcher rd;
    PrintWriter out;
    ResultSet rs;
    int result;

     protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try  {
                out = response.getWriter();
                Class.forName("com.mysql.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/db","mj","joker");
                System.out.println("Connected^");
                pst = conn.prepareStatement("select * from user where id = ? and pass = ?");
                int id = Integer.parseInt(request.getParameter("id"));
                pst.setInt(1,id);
                pst.setString(2,request.getParameter("pass"));
                rs = pst.executeQuery();
                    while(rs.next()){
                    result = rs.getRow();
                 }
                
                    if(result > 0){
                        rd = request.getRequestDispatcher("WelcomeServlet");
                        rd.forward(request, response);
			result = 0;
                    }else{
                        out.println("Failed to login, Please Try again later");
                        rd = request.getRequestDispatcher("index.html");
                        rd.include(request, response);
                    }

              }catch(Exception e){
                    System.out.println(e);
            }

      @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
