/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.beans;

/**
 *
 * @author Admin
 */
public class ConverterBean {
    private String type;
    private String inputUnit;
    private String outputUnit;
    private double inputValue,result;
    
    public ConverterBean(){}

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getInputUnit() {
        return inputUnit;
    }

    public void setInputUnit(String inputUnit) {
        this.inputUnit = inputUnit;
    }

    public String getOutputUnit() {
        return outputUnit;
    }

    public void setOutputUnit(String outputUnit) {
        this.outputUnit = outputUnit;
    }

    public double getInputValue() {
        return inputValue;
    }

    public void setInputValue(double inputValue) {
        this.inputValue = inputValue;
    }

    public double getResult() {
        if(type.equalsIgnoreCase("length"))
        {
            if(inputUnit.equalsIgnoreCase(outputUnit))
                result=inputValue;
            else if(inputUnit.equalsIgnoreCase("centimeter")&& outputUnit.equalsIgnoreCase("meter"))
                result = inputValue/100;
            else if(inputUnit.equalsIgnoreCase("meter")&& outputUnit.equalsIgnoreCase("centimeter"))
                result = inputValue*100;
            else if(inputUnit.equalsIgnoreCase("meter")&& outputUnit.equalsIgnoreCase("inch"))
                result = inputValue*39.37;
            else if(inputUnit.equalsIgnoreCase("inch")&& outputUnit.equalsIgnoreCase("centimeter"))
                result=inputValue*2.54;
            else if(inputUnit.equalsIgnoreCase("inch")&& outputUnit.equalsIgnoreCase("meter"))
                result=inputValue/39.37;
            else if(inputUnit.equalsIgnoreCase("centimeter")&& outputUnit.equalsIgnoreCase("inch"))
                result = inputValue/2.54;
        }else if(type.equalsIgnoreCase("temperature"))
        {
            if(inputUnit.equalsIgnoreCase(outputUnit))
                result=inputValue;
            else if(inputUnit.equalsIgnoreCase("celsius") && outputUnit.equalsIgnoreCase("fehrenheit"))
                result=(inputValue*9/5)+32;
            else if(inputUnit.equalsIgnoreCase("fehrenheit") && outputUnit.equalsIgnoreCase("celsius"))
                result=(inputValue-32)*5/9;
        }
        else
            throw new IllegalArgumentException("Sorry Something is wrong with provided data");
        result=Double.parseDouble(String.format("%.4f", result));
        return result;
    }

    @Override
    public String toString() {
        return "ConverterBean2{" + "type=" + type + ", inputUnit=" + inputUnit + ", outputUnit=" + outputUnit + ", inputValue=" + inputValue + ", result=" + result + '}';
    }
  
}
