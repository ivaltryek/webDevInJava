
package com.app;
import com.app.Movie;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ControllerServlet extends HttpServlet {
    RequestDispatcher rd;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String genre = request.getParameter("list");
            System.out.println(genre);
            Movie mo = new Movie();
            
           ArrayList<String> action = new ArrayList<>();           
           switch(genre){
               case "action":
                   action.add("Avengers");
                   action.add("Deadpool");
                   action.add("Fast and Furious");
                   break;
               case "scifi":
                   action.add("Avatar");
                   action.add("Rampage");
                   action.add("Ready player One");
                   break;
               case "comedy":
                   action.add("Friends");
                   action.add("Johnny English");
                   action.add("Mr. Bean");
           }
           mo.setGenre(genre);
           mo.setArr(action);
                request.setAttribute("mymovies", mo);
                rd = request.getRequestDispatcher("DisplayMovieList.jsp");
                rd.forward(request, response);
            
           
         
         }catch(Exception e){
             System.out.println(e);
           }
            
        }
    

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }
}