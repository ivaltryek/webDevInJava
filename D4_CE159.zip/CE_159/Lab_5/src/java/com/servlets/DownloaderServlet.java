
package com.servlets;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class DownloaderServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
       String fname=request.getParameter("filename");
       String mimeType=getServletContext().getMimeType(request.getContextPath()+fname);
       
       response.setContentType(mimeType);
       response.setHeader("Content-Disposition","attachment;filename="+fname);
       
       System.out.println("\n"+mimeType+" filename="+fname);
       System.out.println("\n"+"/downloads/"+fname);
       try(ServletOutputStream sos=response.getOutputStream();){
           InputStream fin=getServletContext().getResourceAsStream("/downloads/"+fname);
           if(fin!=null)
           {
               byte[] buffer=new byte[1024];
               while(fin.read(buffer)!=-1)
                  sos.write(buffer);
               sos.flush();
               fin.close();
           }
           else
           {
               System.out.print("file not opened");
           }
       }
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    public String getServletInfo() {
        return "Short description";
    }

}