/*
    
    Lab 2:Working with JDBC and Servlets

   1.Write a Java application to fetch records of student registration and practice the use of the 
    following methods of ResultSet interface: absolute(), afterLast(), beforeFirst(), first(),isFirst(),
    isLast(),last(),previous(),next(),relative()


*/

package datafetcher;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user1
 */
public class DataFetcher {

    /**
     * @param args the command line arguments
     * @throws java.lang.ClassNotFoundException
     */
    public static void main(String[] args) throws ClassNotFoundException {
        // TODO code application logic here
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        String url = "jdbc:mysql://192.168.29.150:3306/ce159";
        String pass = "ce159";
        String user = "ce159";
        String query = "select * from Student";
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(url,user,pass);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            rs = stmt.executeQuery(query);
            System.out.println(rs.absolute(3)); // true
            rs.last();
            System.out.println(rs.isFirst());//false
            rs.first();
            rs.last();
            System.out.println(rs.isLast());//true
            rs.relative(0);
            System.out.println(rs.getString(3));
            rs.afterLast();
            rs.beforeFirst();
            System.out.println(rs.previous());//false
            while(rs.next()){
                System.out.println("Roll: "+rs.getInt(1)+" "+" Name: "+rs.getString(2)+" "+" CPI: "+rs.getDouble(3));
            }
        }catch(ClassNotFoundException | SQLException e){
            System.out.println(e);
        }finally{
            try{
                stmt.close();
                rs.close();
                conn.close();
                
            } catch (SQLException ex) {
                Logger.getLogger(DataFetcher.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    
}