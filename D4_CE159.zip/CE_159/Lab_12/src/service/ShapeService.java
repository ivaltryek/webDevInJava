/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;
import model.*;

/**
 *
 * @author user1
 */
public class ShapeService {
    private Circle circle;
    private Triangle triangle;

    public Circle getCircle() {
        System.out.println("get Circle is call");
        return circle;
    }

    public void setCircle(Circle circle) {
        System.out.println("set Circle is call");
        this.circle = circle;
        
    }

    public Triangle getTriangle() {
        System.out.println("get Triangle is call");
        return triangle;
    }

    public void setTriangle(Triangle triangle) {
        System.out.println("set Triangle is call");
        this.triangle = triangle;
    }
}
