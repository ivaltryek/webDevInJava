/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

/**
 *
 * @author user1
 */

@Aspect
public class loginaspect {
   @Before("execution(public * get*(..)) && within(service.*)")
   public void loginadvice()
   {
       System.out.println("this is @Before for GETTERs");
       System.out.println();
   }
   @After("execution(public * get*(..)) && within(service.*)")
   public void afterAdvice()
   {
       
       System.out.println("This is @After Advice for GETTERs\n");
   }
}
