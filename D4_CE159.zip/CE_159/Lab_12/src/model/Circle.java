/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author user1
 */
public class Circle {
    int x;
    int y;

    public int getX() {
        System.out.println("I am getX");
        return x;
    }

    public void setX(int x) {
        System.out.println("I am setX");
        this.x = x;
    }

    public int getY() {
        System.out.println("I am getY");
        return y;
    }

    public void setY(int y) {
        System.out.println("I am sety");
        this.y = y;
    }

    public int getRadius() {
        System.out.println("I am getRedius");
        return radius;
    }

    public void setRadius(int radius) {
        System.out.println("I am setRadius");
        this.radius = radius;
    }
    int radius;
}
