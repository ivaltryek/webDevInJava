/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author user1
 */
public class Triangle {
    String Type;

    public String getType() {
        System.out.println("get method of triangle is called");
        return Type;
    }

    public void setType(String Type) {
        System.out.println("set method of triangle is called");
        this.Type = Type;
    }
    
}
