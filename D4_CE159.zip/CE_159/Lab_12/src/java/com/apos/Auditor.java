/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.apos;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

/**
 *
 * @author Admin
 */
@Component
@Aspect
public class Auditor {
    Logger logger=Logger.getLogger("Auditor");
    
    @Before("within(com.*) && execution(public void set*(..)")
    public void auditBeforeChange()
    {
        logger.log(Level.INFO,"Property About to be changed");
    }
    
    @After("within(com.*) && execution(public void set*(..)")
    public void auditAfterChange()
    {
        logger.log(Level.INFO,"Property is changed");
    }
    
    @Before("execution(public com.* get*())")
    public void auditToBeRetrieved()
    {
        logger.log(Level.INFO,"Property about to be retrived ... ");
    }
    
    
    @After("execution(public com.* get*())")
    public void auditAfterRetrieved()
    {
        logger.log(Level.INFO,"Property is retrived ... ");
    }
	
}
