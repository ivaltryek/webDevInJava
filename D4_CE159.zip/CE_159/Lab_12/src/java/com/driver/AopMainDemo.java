/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.driver;

import com.beans.Circle;
import com.beans.Triangle;
import com.services.ShapeService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

/**
 *
 * @author Admin
 */
@SpringBootApplication
public class AopMainDemo {
    public static void main(String[] args) {
            ApplicationContext context = SpringApplication.run(AopMainDemo.class, args);
            System.out.println("Hello AOP");


            Triangle triangle = (Triangle)context.getBean("triangle");
            triangle.setType("Equilateral");

            Circle circle = (Circle) context.getBean("circle");
            circle.setRadius(50);
            circle.setX(5);
            circle.setY(12);

            ShapeService ss = (ShapeService) context.getBean("shapeService");
            System.out.println(ss.getCircle().getRadius());
            System.out.println(ss.getTriangle().getType());
            System.out.println(ss.getCircle().getRadius());
            System.out.println(ss.getTriangle().getType());	
	}
}
