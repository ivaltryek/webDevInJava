/* 
Lab 1.1:

Introduction to Netbeans IDE and JDBC

Create a Java application consisting of the following components:

a. Student class with private data members: int id, String name, double cpi. Default 
constructor, parameterized constructor, getter-setter methods and toString
method.
*/
package com.mypack;

public class Student {
    private int id;
    private String name;
    private double cpi;

    public Student() {
        System.out.println("Default Constructor..!");
    }

    public Student(int id, String name, double cpi) {
        this.id = id;
        this.name = name;
        this.cpi = cpi;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCpi(double cpi) {
        this.cpi = cpi;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getCpi() {
        return cpi;
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", name=" + name + ", cpi=" + cpi + '}';
    }
    
    
    
}

