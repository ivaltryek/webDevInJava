
package l1;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;

public class NewServletListener implements ServletContextListener, ServletRequestListener {

    
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext sc=sce.getServletContext();
        int count=0;
        sc.setAttribute("counter",count);
    }

    
    public void contextDestroyed(ServletContextEvent sce) {
    }

    
    public void requestDestroyed(ServletRequestEvent sre) {
        System.out.println("request is destroyed");
    }

  
    public void requestInitialized(ServletRequestEvent sre) {
        System.out.println("request is created");
        ServletContext sc=sre.getServletContext();
        int count=(int)(sc.getAttribute("counter"));
        sc.setAttribute("counter",count+1);
    }
}
