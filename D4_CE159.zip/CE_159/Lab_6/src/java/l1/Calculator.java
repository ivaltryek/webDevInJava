
package l1;

public class Calculator {
    private int op1;
    private int op2;
    private String opr;
    private int res;

    
    public Calculator() {
    }

   public Calculator(int op1, int op2, String opr, int res) {
        this.op1 = op1;
        this.op2 = op2;
        this.opr = opr;
        this.res = res;
    }


    public int getOp1() {
        return op1;
    }

    public void setOp1(int op1) {
        this.op1 = op1;
    }

    public int getOp2() {
        return op2;
    }

    public void setOp2(int op2) {
        this.op2 = op2;
    }

    public String getOpr() {
        return opr;
    }

    public void setOpr(String opr) {
        this.opr = opr;
    }
    public int getRes() {
        if(opr.equals("+"))
        {
            return op1+op2;
        } 
        else if(opr.equals("-"))
        {
            return op1-op2;
        }
        else if(opr.equals("*"))
        {
            return op1*op2;
        }
        else if(opr.equals("/"))
        {
            return op1/op2;
        }
        else
        {
            return 0;
        }
    }
    
}
