/*

Lab1.1:

Introduction to Netbeans IDE and JDBC

Create a Java application consisting of the following components:

b.DemoStudent class has main method to create various Student objects Using command-line-argument

Taking input from user at runtime

*/


package com.mypack;

import java.util.Scanner;

public class DemoStudent {
    public static void main(String ar[]){
        Scanner sc = new Scanner(System.in);
        String name;
        int id;
        double cpi;
        Student arr[] = new Student[3];
        for(int i=0; i<3; i++){
            id = sc.nextInt();
            name = sc.next();
            cpi = sc.nextDouble();
            arr[i] = new Student(id,name,cpi);
            System.out.println(arr[i].toString());
        }
        
    }
    
}