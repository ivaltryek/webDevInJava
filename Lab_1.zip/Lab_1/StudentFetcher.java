/*
    Lab 1:
	Introduction to Netbeans IDE and JDBC

     2.Write a Java application to fetch student registration information 
     (like firstName, lastName,branch, username and password) from database using JDBC. 
     (Using Statement object)

*/


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class StudentFetcher {
    public static void main(String ar[]){
    Connection conn = null;
    Statement stmt = null;
    ResultSet rs;
    String url = "jdbc:mysql://192.168.29.150:3306/ce159";
    String pass = "ce159";
    String user = "ce159";
    String query = "select * from Student";

    try{
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection(url,user,pass);
        stmt = conn.createStatement();
        rs = stmt.executeQuery(query);
        while(rs.next()){
                System.out.println("Roll: "+rs.getInt(1)+" "+" Name: "+rs.getString(2)+" "+" CPI: "+rs.getDouble(3));
            }
    }catch(Exception e){
            System.out.println(e);
       }
    
    }
}  
